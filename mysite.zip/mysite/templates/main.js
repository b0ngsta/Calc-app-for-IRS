 Vue.component( 'product', {template:`
    <div class="result_space">
          <p>OUTPUTS:</p>
          <hr>
          <p> volume: [[ M1() ]] </p>
          <hr>
          <p> Weight compare: [[ M2()]]</p>
          <hr>
          <p>Total weight: <br> </span><span>[[ M3() ]]</p>
            <hr>
          <p><span> Indirect (I) </span> <br> <span>[[ M4() ]] %</span></p>
          <hr>
          <p><span> Direct (D) <br></span><span>[[ M5() ]] %</span></p>
          <hr>
          <p><span>Order Price</span> <br> <span>$</span>[[ M6() ]]</p>
          <hr>
          <p><span>China Ex Price <br> $ [[ M7() ]]</span></p>
          <hr>
          <p><span>Order Price INR (D) <br> [[ M8()]]</span></p>
          <hr>
          <p><span> Freight Charges <br> [[ M9()]]</span></p>
          <hr>
          <p><span>Insurance Value <br> [[ M10()]]</span></p>
          <hr>
          <p><span>Landing Value<br> [[ M11()]]</span></p>
          <hr>
          <p><span>Assessable Value <br> [[ M12()]]</span></p>
          <hr>
          <p><span>BCD Value<br> [[ M13()]]</span></p>
          <hr>
          <p><span>CD total<br> [[ M14()]]</span></p>
          <hr>
          <p><span>Total Shipping <br> [[ M15()]]</span></p>
          <hr>
          <p><span> Total (CD + Shipping)<br> [[ M16()]]</span></p>
          <hr>
          <p><span>Profit on  CP<br> [[ M17()]]</span></p>
          <hr>
          <p><span>selling  1 + price <br> [[ M21()]]</span></p>
          <hr>
          <p><span>selling  1 + GST <br> [[ M22()]]</span></p>
          <hr>
          <p><span>selling  2 + price <br> [[ M23()]]</span></p>
          <hr>
          <p><span>selling  2 + GST <br> [[ M24()]]</span></p>
          <hr>
          <p><span>selling  3 + price <br> [[ M25()]]</span></p>
          <hr>
          <p><span>selling  3 + GST <br> [[ M26()]]</span></p>
          <hr>
          <p><span>indirect <br> [[ M27()]]</span></p>
          <hr>
          <p><span>USD TO RMB <br> [[ M28()]]</span></p>
          
      
        </div>
                          
        `,
        data () {
          return {
                                vertical: true,
                                e6: 1,
                                height: '',
                                length: '',
                                width: '',
                                packing: '',
                                weight: '',
                                unit_price: '',
                                direct_unit_price: '',
                                Paypal: '',
                                Rate_of_ex_inr: '',
                                Freight: '',
                                Insurance: '',
                                Landing: '',
                                Basic_duty: '',
                                GST: '',
                                Shipping_fee: '',
                                Fuel_charges: '',
                                Extra_shipping_per_kg: '',
                                IRS_Profit: '',
                                Income_tax: '',
                                GST2: '',
                                RMB: '',
                                RMB_to_INR: '',
                                order_qty: ''

                              }
                            },
                            methods: {
                                
                                M1: function(){
                                  return this.length*this.width*this.height/5000;
                                },
                                
                                M2: function(){
                                  
                                  var a = this.length*this.width*this.height/5000;
                                  var b = this.weight;
                                  return Math.max(a,b);
                                  
                                },
                                
                                M3: function(){
                                  var a = (this.length*this.width*this.height/5000);
                                  var b = this.weight;
                                  var result = Math.max(a , b);
                                return ((result*this.packing/100)*this.order_qty+ result*this.order_qty);
                               },
                                
                                M4: function(){
                                //  var y =  parseFloat(100 - this.direct_unit_price/this.unit_price*100);
                                  var a = this.unit_price;
                                  var d = this.direct_unit_price;
                                  var c = parseFloat(a-d);
                                  var b = c/a*100;
                                  return b;
                                },
                                M5: function(){
                                  return (100- ((this.unit_price-this.direct_unit_price)/this.unit_price)*100);
                                },
                                M6: function(){
                                  return (this.direct_unit_price*this.order_qty);
                                },
                                M7: function(){
                                  return this.direct_unit_price*this.order_qty + (this.direct_unit_price*this.order_qty*this.Paypal)/100;
                                  
                                },
                                M8: function(){    
                                   return this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr;
                                 },                
                               M9: function(){ 
                                 return ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100;
                               },
                               M10: function(){                      
                               return (this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000;
                               },
                               M11: function(){ 
                                 return (this.direct_unit_price*this.order_qty + (this.direct_unit_price*this.order_qty*this.Paypal)/100)*(this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Landing/100;

                               },
                               M12: function(){
                                  return   (this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr; 
                                                                                                     },
                               M13: function(){
                                 return ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty/100;
                               },
                               M14: function(){
                                 return ((((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty)/1000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty/100 +   (this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.GST/100 + (((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty)/1000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty/100;
                               },
                               M15: function(){
                                return this.Fuel_charges*(this.Shipping_fee*((Math.max(this.length*this.width*this.height/5000 ,this.weight)*this.packing/100)*this.order_qty + Math.max(this.length*this.width*this.height/5000 , this.weight)*this.order_qty))/100 + this.Shipping_fee*((Math.max(this.length*this.width*this.height/5000 ,this.weight)*this.packing/100)*this.order_qty + Math.max(this.length*this.width*this.height/5000 , this.weight)*this.order_qty) + (this.Fuel_charges*(this.Shipping_fee*((Math.max(this.length*this.width*this.height/5000 ,this.weight)*this.packing/100)*this.order_qty + Math.max(this.length*this.width*this.height/5000 , this.weight)*this.order_qty))/100 + this.Shipping_fee*((Math.max(this.length*this.width*this.height/5000 ,this.weight)*this.packing/100)*this.order_qty + Math.max(this.length*this.width*this.height/5000 , this.weight)*this.order_qty))*18/100;
                               },                
                               M16: function(){ 
                                return ((((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty)/1000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty/100 +   (this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.GST/100 + (((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty)/1000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty/100    + this.Fuel_charges*(this.Shipping_fee*((Math.max(this.length*this.width*this.height/5000 ,this.weight)*this.packing/100)*this.order_qty + Math.max(this.length*this.width*this.height/5000 , this.weight)*this.order_qty))/100 + this.Shipping_fee*((Math.max(this.length*this.width*this.height/5000 ,this.weight)*this.packing/100)*this.order_qty + Math.max(this.length*this.width*this.height/5000 , this.weight)*this.order_qty) + (this.Fuel_charges*(this.Shipping_fee*((Math.max(this.length*this.width*this.height/5000 ,this.weight)*this.packing/100)*this.order_qty + Math.max(this.length*this.width*this.height/5000 , this.weight)*this.order_qty))/100 + this.Shipping_fee*((Math.max(this.length*this.width*this.height/5000 ,this.weight)*this.packing/100)*this.order_qty + Math.max(this.length*this.width*this.height/5000 , this.weight)*this.order_qty))*18/100;
                               },
                               M17: function(){
                                var a = this.unit_price;
                                var d = this.direct_unit_price;
                                var c = parseFloat(a-d);
                                var b = c/a*100;
                                var CN = b*this.unit_price/100;
                                var CR = parseFloat(this.RMB_to_INR) + 0.5;
                                var CS = CR*CN*6.9;
                                // var f = parseFloat(this.RMB_to_INR);
                                // var yup = 0.5 + f;
                                var CT = CS*this.order_qty;
                                var ab=  this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr
                                var BJ = ab + CT;
                                var BR = BJ*this.IRS_Profit/100;
                                // var an = (this.length*this.width*this.height/5000);
                                // var bn = this.weight;
                                // var result = Math.max(an , bn);
                                // var BI =  (this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result))*this.Income_tax/100 + this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Fuel_charges*(this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result))/100
                                // var AO = ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty/100
                                // var AP = AO/10;
                                // var BK = AP + AO;
                                // var BS = BR*this.Income_tax/100;
                                return BR;

                               },


                             M21: function(){
                              var a = this.unit_price;
                                var d = this.direct_unit_price;
                                var c = parseFloat(a-d);
                                var b = c/a*100;
                                var CN = b*this.unit_price/100;
                                var CR = parseFloat(this.RMB_to_INR) + 0.5;
                                var CS = CR*CN*6.9;
                                var CT = CS*this.order_qty;
                                var ab=  this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr
                                var BJ = ab + CT;
                                var BR = BJ*this.IRS_Profit/100;
                                var an = (this.length*this.width*this.height/5000);
                                var bn = this.weight;
                                var result = Math.max(an , bn);
                                var BI =  (this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result))*this.Income_tax/100 + this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Fuel_charges*(this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result))/100
                                var AO = ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty/100
                                var AP = AO/10;
                                var BK = AP + AO;
                                var BS = BR*this.Income_tax/100;
                                return BS + BI +BJ+ BK +BR;                               
                             },
                             M22: function(){
                              var a = this.unit_price;
                                var d = this.direct_unit_price;
                                var c = parseFloat(a-d);
                                var b = c/a*100;
                                var CN = b*this.unit_price/100;
                                var CR = parseFloat(this.RMB_to_INR) + 0.5;
                                var CS = CR*CN*6.9;
                                var CT = CS*this.order_qty;
                                var ab=  this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr
                                var BJ = ab + CT;
                                var BR = BJ*this.IRS_Profit/100;
                                var an = (this.length*this.width*this.height/5000);
                                var bn = this.weight;
                                var result = Math.max(an , bn);
                                var BI =  (this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result))*this.Income_tax/100 + this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Fuel_charges*(this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result))/100
                                var AO = ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty/100
                                var AP = AO/10;
                                var BK = AP + AO;
                                var BS = BR*this.Income_tax/100;
                                var BT = BS + BI +BJ+ BK +BR;
                                 return (BS + BI +BJ+ BK +BR)*this.GST2/100 + BS + BI +BJ+ BK +BR;

                             },
                            M23: function(){
                                var a = this.unit_price;
                                var d = this.direct_unit_price;
                                var c = parseFloat(a-d);
                                var b = c/a*100;
                                var CN = b*this.unit_price/100;
                                var CR = parseFloat(this.RMB_to_INR) + 0.5;
                                var CS = CR*CN*6.9;
                                var CT = CS*this.order_qty;
                                var ab=  this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr
                                var BJ = ab + CT;
                                var BR = BJ*this.IRS_Profit/100;
                                var an = (this.length*this.width*this.height/5000);
                                var bn = this.weight;
                                var result = Math.max(an , bn);
                                var BI =  (this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result))*this.Income_tax/100 + this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Fuel_charges*(this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result))/100;
                                var AO = ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty/100;
                                var AP = AO/10;
                                var BK = AP + AO;
                                var BZ = (BJ + BK)*this.IRS_Profit/100;
                                var BL = BJ + BK;
                                var CA = BZ*this.Income_tax/100;
                                return CA + BZ +BI + BL;
                             },
                             M24: function(){
                              var a = this.unit_price;
                                var d = this.direct_unit_price;
                                var c = parseFloat(a-d);
                                var b = c/a*100;
                                var CN = b*this.unit_price/100;
                                var CR = parseFloat(this.RMB_to_INR) + 0.5;
                                var CS = CR*CN*6.9;
                                var CT = CS*this.order_qty;
                                var ab=  this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr
                                var BJ = ab + CT;
                                var BR = BJ*this.IRS_Profit/100;
                                var an = (this.length*this.width*this.height/5000);
                                var bn = this.weight;
                                var result = Math.max(an , bn);
                                var BI =  (this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result))*this.Income_tax/100 + this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Fuel_charges*(this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result))/100;
                                var AO = ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty/100;
                                var AP = AO/10;
                                var BK = AP + AO;
                                var BZ = (BJ + BK)*this.IRS_Profit/100;
                                var BL = BJ + BK;
                                var CA = BZ*this.Income_tax/100;
                                return (CA + BZ +BI + BL)*this.GST2/100 + CA + BZ +BI + BL;


                             },
                             M25: function(){
                              var a = this.unit_price;
                                var d = this.direct_unit_price;
                                var c = parseFloat(a-d);
                                var b = c/a*100;
                                var CN = b*this.unit_price/100;
                                var CR = parseFloat(this.RMB_to_INR) + 0.5;
                                var CS = CR*CN*6.9;
                                var CT = CS*this.order_qty;
                                var ab=  this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr
                                var BJ = ab + CT;
                                var BR = BJ*this.IRS_Profit/100;
                                var an = (this.length*this.width*this.height/5000);
                                var bn = this.weight;
                                var result = Math.max(an , bn);
                                var BI =  (this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result))*this.Income_tax/100 + this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Fuel_charges*(this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result))/100;
                                var AO = ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty/100;
                                var AP = AO/10;
                                var BK = AP + AO;
                                var CG = (BJ + BK + BI)*this.IRS_Profit/100;
                                return CG*this.Income_tax/100 + CG +BI +BJ + BK;
                             },
                             M26: function(){
                              var a = this.unit_price;
                                var d = this.direct_unit_price;
                                var c = parseFloat(a-d);
                                var b = c/a*100;
                                var CN = b*this.unit_price/100;
                                var CR = parseFloat(this.RMB_to_INR) + 0.5;
                                var CS = CR*CN*6.9;
                                var CT = CS*this.order_qty;
                                var ab=  this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr
                                var BJ = ab + CT;
                                var BR = BJ*this.IRS_Profit/100;
                                var an = (this.length*this.width*this.height/5000);
                                var bn = this.weight;
                                var result = Math.max(an , bn);
                                var BI =  (this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result))*this.Income_tax/100 + this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Fuel_charges*(this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result))/100;
                                var AO = ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty/100;
                                var AP = AO/10;
                                var BK = AP + AO;
                                var CG = (BJ + BK + BI)*this.IRS_Profit/100;
                                var CI = CG*this.Income_tax/100 + CG +BI +BJ + BK;
                                return CI*this.GST2/100 + CI;
                             },
                             M27: function(){
                              var a = this.unit_price;
                                var d = this.direct_unit_price;
                                var c = parseFloat(a-d);
                                var b = c/a*100;
                                var CN = b*this.unit_price/100;
                                var CR = parseFloat(this.RMB_to_INR) + 0.5;
                                var CS = CR*CN*6.9;
                               
                                
                                return CN;
                             },
                             M28: function(){
                                var a = this.unit_price;
                                var d = this.direct_unit_price;
                                var c = parseFloat(a-d);
                                var b = c/a*100;
                                var CN = b*this.unit_price/100;
                                var CR = parseFloat(this.RMB_to_INR) + 0.5;
                                var CS = CR*CN*6.9;
                                return CN*6.9;
                             }
                              
                                                     
                                                     
                                                     
                                                     
                                                     
                                                     
                                                     
                                                     
                              }


                            })

                          var app = new Vue({
                            el: '#app',
                            delimiters : ['[[', ']]'],
                            data () {
                              return {
                                vertical: true,
                                e6: 1,
                                height: '80',
                                length: '230',
                                width: '140',
                                packing: '8',
                                weight: '1',
                                unit_price: '125',
                                direct_unit_price: '30',
                                Paypal: '7.05',
                                Rate_of_ex_inr: '70',
                                Freight: '20',
                                Insurance: '5.62',
                                Landing: '0',
                                Basic_duty: '10',
                                GST: '18',
                                Shipping_fee: '356',
                                Fuel_charges: '21',
                                Extra_shipping_per_kg: '200',
                                IRS_Profit: '30',
                                Income_tax: '35',
                                GST2: '18',
                                RMB: '6.9',
                                RMB_to_INR: '10.4',
                                order_qty: '1'

                              }
                            },
                            methods: {
                                
                                M1: function(){
                                  return this.length*this.width*this.height/5000000;
                                },
                                
                                M2: function(){
                                  
                                  var a = this.length*this.width*this.height/5000000;
                                  var b = this.weight;
                                  return Math.max(a,b);
                                  
                                },
                                
                                M3: function(){
                                  var a = (this.length*this.width*this.height/5000000);
                                  var b = this.weight;
                                  var result = Math.max(a , b);
                                return ((result*this.packing/100)*this.order_qty+ result*this.order_qty);
                               },
                                
                                M4: function(){
                                //  var y =  parseFloat(100 - this.direct_unit_price/this.unit_price*100);
                                  var a = this.unit_price;
                                  var d = this.direct_unit_price;
                                  var c = parseFloat(a-d);
                                  var b = c/a*100;
                                  return b;
                                },
                                M5: function(){
                                  return (100- ((this.unit_price-this.direct_unit_price)/this.unit_price)*100);
                                },
                                M6: function(){
                                  return (this.direct_unit_price*this.order_qty);
                                },
                                M7: function(){
                                  return this.direct_unit_price*this.order_qty + (this.direct_unit_price*this.order_qty*this.Paypal)/100;
                                  
                                },
                                M8: function(){    
                                   return this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr;
                                 },                
                               M9: function(){ 
                                 return ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100;
                               },
                               M10: function(){                      
                               return (this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000;
                               },
                               M11: function(){ 
                                 return (this.direct_unit_price*this.order_qty + (this.direct_unit_price*this.order_qty*this.Paypal)/100)*(this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Landing/100;

                               },
                               M12: function(){
                                  return   (this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr; 
                                                                                                     },
                               M13: function(){
                                 return ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty/100;
                               },
                               M14: function(){
                                 return ((((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty)/1000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty/100 +   (this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.GST/100 + (((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty)/1000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty/100;
                               },
                               M15: function(){
                                return this.Fuel_charges*(this.Shipping_fee*((Math.max(this.length*this.width*this.height/5000000 ,this.weight)*this.packing/100)*this.order_qty + Math.max(this.length*this.width*this.height/5000000 , this.weight)*this.order_qty))/100 + this.Shipping_fee*((Math.max(this.length*this.width*this.height/5000000 ,this.weight)*this.packing/100)*this.order_qty + Math.max(this.length*this.width*this.height/5000000 , this.weight)*this.order_qty) + (this.Fuel_charges*(this.Shipping_fee*((Math.max(this.length*this.width*this.height/5000000 ,this.weight)*this.packing/100)*this.order_qty + Math.max(this.length*this.width*this.height/5000000 , this.weight)*this.order_qty))/100 + this.Shipping_fee*((Math.max(this.length*this.width*this.height/5000000 ,this.weight)*this.packing/100)*this.order_qty + Math.max(this.length*this.width*this.height/5000000 , this.weight)*this.order_qty))*18/100;
                               },                
                               M16: function(){ 
                                return ((((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty)/1000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty/100 +   (this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.GST/100 + (((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty)/1000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty/100    + this.Fuel_charges*(this.Shipping_fee*((Math.max(this.length*this.width*this.height/5000000 ,this.weight)*this.packing/100)*this.order_qty + Math.max(this.length*this.width*this.height/5000000 , this.weight)*this.order_qty))/100 + this.Shipping_fee*((Math.max(this.length*this.width*this.height/5000000 ,this.weight)*this.packing/100)*this.order_qty + Math.max(this.length*this.width*this.height/5000000 , this.weight)*this.order_qty) + (this.Fuel_charges*(this.Shipping_fee*((Math.max(this.length*this.width*this.height/5000000 ,this.weight)*this.packing/100)*this.order_qty + Math.max(this.length*this.width*this.height/5000000 , this.weight)*this.order_qty))/100 + this.Shipping_fee*((Math.max(this.length*this.width*this.height/5000000 ,this.weight)*this.packing/100)*this.order_qty + Math.max(this.length*this.width*this.height/5000000 , this.weight)*this.order_qty))*18/100;
                               },
                               M17: function(){
                                var a = this.unit_price;
                                var d = this.direct_unit_price;
                                var c = parseFloat(a-d);
                                var b = c/a*100;
                                var CN = b*this.unit_price/100;
                                var CR = parseFloat(this.RMB_to_INR) + 0.5;
                                var CS = CR*CN*6.9;
                                // var f = parseFloat(this.RMB_to_INR);
                                // var yup = 0.5 + f;
                                var CT = CS*this.order_qty;
                                var ab=  this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr
                                var BJ = ab + CT;
                                var BR = BJ*this.IRS_Profit/100;
                                // var an = (this.length*this.width*this.height/5000000);
                                // var bn = this.weight;
                                // var result = Math.max(an , bn);
                                // var BI =  (this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result))*this.Income_tax/100 + this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Fuel_charges*(this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result))/100
                                // var AO = ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty/100
                                // var AP = AO/10;
                                // var BK = AP + AO;
                                // var BS = BR*this.Income_tax/100;
                                return BR;

                               },


                             M21: function(){
                              var a = this.unit_price;
                                var d = this.direct_unit_price;
                                var c = parseFloat(a-d);
                                var b = c/a*100;
                                var CN = b*this.unit_price/100;
                                var CR = parseFloat(this.RMB_to_INR) + 0.5;
                                var CS = CR*CN*6.9;
                                var CT = CS*this.order_qty;
                                var ab=  this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr
                                var BJ = ab + CT;
                                var BR = BJ*this.IRS_Profit/100;
                                var an = (this.length*this.width*this.height/5000000);
                                var bn = this.weight;
                                var result = Math.max(an , bn);
                                var BI =  (this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result))*this.Income_tax/100 + this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Fuel_charges*(this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result))/100
                                var AO = ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty/100
                                var AP = AO/10;
                                var BK = AP + AO;
                                var BS = BR*this.Income_tax/100;
                                return BS + BI +BJ+ BK +BR;                               
                             },
                             M22: function(){
                              var a = this.unit_price;
                                var d = this.direct_unit_price;
                                var c = parseFloat(a-d);
                                var b = c/a*100;
                                var CN = b*this.unit_price/100;
                                var CR = parseFloat(this.RMB_to_INR) + 0.5;
                                var CS = CR*CN*6.9;
                                var CT = CS*this.order_qty;
                                var ab=  this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr
                                var BJ = ab + CT;
                                var BR = BJ*this.IRS_Profit/100;
                                var an = (this.length*this.width*this.height/5000000);
                                var bn = this.weight;
                                var result = Math.max(an , bn);
                                var BI =  (this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result))*this.Income_tax/100 + this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Fuel_charges*(this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result))/100
                                var AO = ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty/100
                                var AP = AO/10;
                                var BK = AP + AO;
                                var BS = BR*this.Income_tax/100;
                                var BT = BS + BI +BJ+ BK +BR;
                                 return (BS + BI +BJ+ BK +BR)*this.GST2/100 + BS + BI +BJ+ BK +BR;

                             },
                            M23: function(){
                                var a = this.unit_price;
                                var d = this.direct_unit_price;
                                var c = parseFloat(a-d);
                                var b = c/a*100;
                                var CN = b*this.unit_price/100;
                                var CR = parseFloat(this.RMB_to_INR) + 0.5;
                                var CS = CR*CN*6.9;
                                var CT = CS*this.order_qty;
                                var ab=  this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr
                                var BJ = ab + CT;
                                var BR = BJ*this.IRS_Profit/100;
                                var an = (this.length*this.width*this.height/5000000);
                                var bn = this.weight;
                                var result = Math.max(an , bn);
                                var BI =  (this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result))*this.Income_tax/100 + this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Fuel_charges*(this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result))/100;
                                var AO = ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty/100;
                                var AP = AO/10;
                                var BK = AP + AO;
                                var BZ = (BJ + BK)*this.IRS_Profit/100;
                                var BL = BJ + BK;
                                var CA = BZ*this.Income_tax/100;
                                return CA + BZ +BI + BL;
                             },
                             M24: function(){
                              var a = this.unit_price;
                                var d = this.direct_unit_price;
                                var c = parseFloat(a-d);
                                var b = c/a*100;
                                var CN = b*this.unit_price/100;
                                var CR = parseFloat(this.RMB_to_INR) + 0.5;
                                var CS = CR*CN*6.9;
                                var CT = CS*this.order_qty;
                                var ab=  this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr
                                var BJ = ab + CT;
                                var BR = BJ*this.IRS_Profit/100;
                                var an = (this.length*this.width*this.height/5000000);
                                var bn = this.weight;
                                var result = Math.max(an , bn);
                                var BI =  (this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result))*this.Income_tax/100 + this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Fuel_charges*(this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result))/100;
                                var AO = ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty/100;
                                var AP = AO/10;
                                var BK = AP + AO;
                                var BZ = (BJ + BK)*this.IRS_Profit/100;
                                var BL = BJ + BK;
                                var CA = BZ*this.Income_tax/100;
                                return (CA + BZ +BI + BL)*this.GST2/100 + CA + BZ +BI + BL;


                             },
                             M25: function(){
                              var a = this.unit_price;
                                var d = this.direct_unit_price;
                                var c = parseFloat(a-d);
                                var b = c/a*100;
                                var CN = b*this.unit_price/100;
                                var CR = parseFloat(this.RMB_to_INR) + 0.5;
                                var CS = CR*CN*6.9;
                                var CT = CS*this.order_qty;
                                var ab=  this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr
                                var BJ = ab + CT;
                                var BR = BJ*this.IRS_Profit/100;
                                var an = (this.length*this.width*this.height/5000000);
                                var bn = this.weight;
                                var result = Math.max(an , bn);
                                var BI =  (this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result))*this.Income_tax/100 + this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Fuel_charges*(this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result))/100;
                                var AO = ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty/100;
                                var AP = AO/10;
                                var BK = AP + AO;
                                var CG = (BJ + BK + BI)*this.IRS_Profit/100;
                                return CG*this.Income_tax/100 + CG +BI +BJ + BK;
                             },
                             M26: function(){
                              var a = this.unit_price;
                                var d = this.direct_unit_price;
                                var c = parseFloat(a-d);
                                var b = c/a*100;
                                var CN = b*this.unit_price/100;
                                var CR = parseFloat(this.RMB_to_INR) + 0.5;
                                var CS = CR*CN*6.9;
                                var CT = CS*this.order_qty;
                                var ab=  this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr
                                var BJ = ab + CT;
                                var BR = BJ*this.IRS_Profit/100;
                                var an = (this.length*this.width*this.height/5000000);
                                var bn = this.weight;
                                var result = Math.max(an , bn);
                                var BI =  (this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result))*this.Income_tax/100 + this.Extra_shipping_per_kg*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result) + this.Fuel_charges*(this.Shipping_fee*((result*this.packing/100)*this.order_qty + this.order_qty*result))/100;
                                var AO = ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Insurance*this.Freight/10000 + ((this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Freight)/100 + this.direct_unit_price*this.order_qty*this.Rate_of_ex_inr + (this.direct_unit_price*this.order_qty*this.Paypal)/100*this.Rate_of_ex_inr)*this.Basic_duty/100;
                                var AP = AO/10;
                                var BK = AP + AO;
                                var CG = (BJ + BK + BI)*this.IRS_Profit/100;
                                var CI = CG*this.Income_tax/100 + CG +BI +BJ + BK;
                                return CI*this.GST2/100 + CI;
                             },
                             M27: function(){
                              var a = this.unit_price;
                                var d = this.direct_unit_price;
                                var c = parseFloat(a-d);
                                var b = c/a*100;
                                var CN = b*this.unit_price/100;
                                var CR = parseFloat(this.RMB_to_INR) + 0.5;
                                var CS = CR*CN*6.9;
                               
                                
                                return CN;
                             },
                             M28: function(){
                                var a = this.unit_price;
                                var d = this.direct_unit_price;
                                var c = parseFloat(a-d);
                                var b = c/a*100;
                                var CN = b*this.unit_price/100;
                                var CR = parseFloat(this.RMB_to_INR) + 0.5;
                                var CS = CR*CN*6.9;
                                return CN*6.9;
                             }
                              
                                                     
                                                     
                                                     
                                                     
                                                     
                                                     
                                                     
                                                     
                              }
                              })